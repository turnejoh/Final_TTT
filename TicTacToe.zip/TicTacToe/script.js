togglePic = true ;


let init = function(){

    //CREATE ALL HTML ELEMENTS FOR TABLE
    let table = document.createElement("TABLE");
    let row1 = document.createElement("TR");
    let row2 = document.createElement("TR");
    let row3 = document.createElement("TR");



    let colHeading1 = document.createElement("TH");
    colHeading1.innerText = "";
    let colHeading2 = document.createElement("TH");
    colHeading2.innerText = "";
    let colHeading3= document.createElement("TH");
    colHeading3.innerText = " " ;



    let rowHeading2 =document.createElement("TH");
    rowHeading2.innerText = "";
    let rowHeading3 = document.createElement("TH");
    rowHeading3.innerText = "";



    let data1 = document.createElement("TD");
    let data2 = document.createElement("TD");
    let data3 = document.createElement("TD");
    let data4 = document.createElement("TD");


    data1.innerText = "";
    data2.innerText = "";
    data3.innerText = "";
    data4.innerText = "";




    row1.appendChild(colHeading1);
    row1.appendChild(colHeading2);
    row1.appendChild(colHeading3);


    row2.appendChild(rowHeading2);
    row2.appendChild(data1);
    row2.appendChild(data2);


    row3.appendChild(rowHeading3);
    row3.appendChild(data3);
    row3.appendChild(data4);




    table.appendChild(row1);
    table.appendChild(row2);
    table.appendChild(row3);

    let content = document.getElementById("content");
    content.appendChild(table);
};


/*let row4 = document.createElement("TR");


let colHeading4 = document.createElement("TH");
colHeading4.innerText = " placement4" ;


let rowHeading4 = document.createElement("TH");
rowHeading4.innerText = " placement";


let data5 = document.createElement("TD");
let data6 = document.createElement("TD");
let data7 = document.createElement("TD");
let data8 = document.createElement("TD");
let data9 = document.createElement("TD");



data5.innerText = "blank";
data6.innerText = "blank";
data7.innerText = "up";
data8.innerText = "down";
data9.innerText = "over";


row1.appendChild(colHeading4);


row4.appendChild(rowHeading4);




row4.appendChild(data7);
row4.appendChild(data8);
row4.appendChild(data9);


row3.appendChild(data5);
row3.appendChild(data6);
table.appendChild(row4);*/